package com.xabit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xabit.model.Task;
import com.xabit.repository.TaskRepository;

@Service
public class TaskService {
	@Autowired
	private TaskRepository taskRepository;

	// get all list
	public List<Task> getAllTask() {
		return taskRepository.findAll();
	}

	public Task getTaskById(Integer id) {
		return taskRepository.findById(id).orElse(null);
	}

	public Task createTask(Task task) {
		return taskRepository.save(task);
	}

	
	public Task updateTask(Task task) {
		Task task1 = taskRepository.findById(task.getTaskid()).orElse(null);
		task1.setAssignedTo(task.getAssignedTo());
		task1.setTaskStatus(task.getTaskStatus());
		task1.setSubject(task.getSubject());
		task1.setDueDate(task.getDueDate());
		task1.setPriority(task.getPriority());
		task1.setName(task.getName());
		task1.setRelatedTo(task.getRelatedTo());
		task1.setComments(task.getComments());
		task1.setReminder(task.getReminder());
		task1.setTaskType(task.getTaskType());
		task1.setIncomingcallCount(task.getIncomingcallCount());
		task1.setOutgoingcallCount(task.getOutgoingcallCount());
		task1.setIncomingEmailCount(task.getIncomingEmailCount());
		task1.setOutgoingEmailCount(task.getOutgoingEmailCount());
		task1.setCampaignid(task.getCampaignid());
		task1.setAccountid(task.getAccountid());
		task1.setOpportunityid(task.getOpportunityid());
		task1.setLeadid(task.getLeadid());
		task1.setContactid(task.getContactid());
		
		return taskRepository.save(task1);
	}
	
	public void deleteTask(Integer id) {
		taskRepository.deleteById(id);
	}
}

