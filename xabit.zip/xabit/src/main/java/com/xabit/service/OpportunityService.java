package com.xabit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xabit.model.Opportunity;
import com.xabit.repository.OpportunityRepository;

@Service
public class OpportunityService {
	@Autowired
	private OpportunityRepository opportunityRepository;

	public List<Opportunity> getAllOpportunity() {
		return opportunityRepository.findAll();
	}

        
	public Opportunity getOpportunityById(Integer id) {
		return opportunityRepository.findById(id).orElse(null);
	}
	public List<Opportunity> findByStageIgnoreCase(String stage) {
        return opportunityRepository.findByStageIgnoreCase(stage);
//        return opportunityRepository.findByStage(stage);
    }

	public Opportunity createOpportunity(Opportunity opportunity) {
		return opportunityRepository.save(opportunity);
	}

	
	
	public Opportunity updateOpportunity(Opportunity opportunity) {
		Opportunity opportunity1 = opportunityRepository.findById(opportunity.getOpportunityid()).orElse(null);
		opportunity1.setName(opportunity.getName());
		
		opportunity1.setAmount(opportunity.getAmount());
		opportunity1.setCloseDate(opportunity.getCloseDate());
		opportunity1.setContact(opportunity.getContact());
		opportunity1.setCreatedBy(opportunity.getCreatedBy());
		opportunity1.setDescription(opportunity.getDescription());
		opportunity1.setExpectedRevenue(opportunity.getExpectedRevenue());
		opportunity1.setForecastCategoryName(opportunity.getForecastCategoryName());
		opportunity1.setLastModifiedBy(opportunity.getLastModifiedBy());
		opportunity1.setLastModifiedDate(opportunity.getLastModifiedDate());
		opportunity1.setLeadSource(opportunity.getLeadSource());
		opportunity1.setNextStep(opportunity.getNextStep());
		opportunity1.setType(opportunity.getType());
		opportunity1.setOwner(opportunity1.getOwner());
		opportunity1.setIqScore(opportunity.getIqScore());
		opportunity1.setPricebook2(opportunity.getPricebook2());
		opportunity1.setPrivate(opportunity.isPrivate());
		opportunity1.setProbability(opportunity.getProbability());
		opportunity1.setPrimarycampaignsource(opportunity.getPrimarycampaignsource());
		opportunity1.setOrdernumber(opportunity.getOrdernumber());
		opportunity1.setCurrentGenerators(opportunity.getCurrentGenerators());
		opportunity1.setTrackingNumber(opportunity.getTrackingNumber());
		opportunity1.setMainCompetitor(opportunity.getMainCompetitor());
		opportunity1.setTotalOpportunityQuantity(opportunity.getTotalOpportunityQuantity());
		opportunity1.setOpportunitytype(opportunity.getOpportunitytype());
		opportunity1.setStage(opportunity.getStage());
		opportunity1.setStatus(opportunity.getStatus());
		opportunity1.setAccountid(opportunity.getAccountid());
		return opportunityRepository.save(opportunity);
		
	}
	


	public void deleteOpportunity(Integer id) {
		opportunityRepository.deleteById(id);
	}

}


