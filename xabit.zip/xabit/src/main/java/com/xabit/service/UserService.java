package com.xabit.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xabit.model.User;
import com.xabit.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;

	// get all list
	public List<User> getAllUser() {

		return userRepository.findAll();
	}

	public List<User> findByLanguage(String language) {
		List<User> listUser = userRepository.findByLanguageIgnoreCase(language);
		return listUser; // Return the combined list
	}

	// get by id
	public User getUserByUserid(Integer id) {
		// return userRepository.findById(id).orElse(null);
		return userRepository.findById(id).orElse(null);
	}

	// insert the data and string id logic
	public User createUser(User user) {
//		user.setUserid(generateID());
		user.setAlias(manipulateUserNames(user));
		return userRepository.save(user);
	}
	public String manipulateUserNames(User user) {
		String lastName = user.getLastName();

		if (lastName.length() > 6) {
			lastName = lastName.substring(0, 6);
		}

		String firstName = user.getFirstName().substring(0, 1);

		String modifiedName = lastName + firstName;

		// Check if the alias already exists in the database
		int suffix = 0;
		String aliasToCheck = modifiedName;

		while (isAliasExists(aliasToCheck)) {
			suffix++;
			aliasToCheck = modifiedName + String.format("%02d", suffix);
		}

		user.setAlias(aliasToCheck);

		return aliasToCheck;
	}

	private boolean isAliasExists(String alias) {
		Optional<User> existingUser = userRepository.findByAlias(alias);
		return existingUser.isPresent();
	}

	public User updateUser(User user) {

		User user1 = userRepository.findById(user.getUserid()).orElse(null);
		user1.setUserid(user.getUserid());
		user1.setAlias(user.getAlias());
		user1.setFirstName(user.getFirstName());
		user1.setLastName(user.getLastName());
		user1.setCreatedBy(user.getCreatedBy());
		user1.setCreatedDate(user.getCreatedDate());
		user1.setLastModifiedBy(user.getLastModifiedBy());
		user1.setLastModifiedDate(user.getLastModifiedDate());
		user1.setCompanyName(user.getCompanyName());
		user1.setEmail(user.getEmail());
		user1.setUserName(user.getUserName());
		user1.setLanguage(user.getLanguage());
		user1.setLocale(user.getLocale());
		user1.setMobile(user.getMobile());	
		user1.setTitle(user.getTitle());
		return userRepository.save(user1);
	}

	public void deleteUser(Integer id) {
		userRepository.deleteById(id);
	}

}
