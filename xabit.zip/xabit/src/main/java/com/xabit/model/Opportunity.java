package com.xabit.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Table(name="opportunity")
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Opportunity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer opportunityid;
	@Column(length=120)
	private String name;
	private String amount;
	private Date closeDate;  //date
	private String contact;  //lookup
	private String createdBy;
	@Column(length=255)
	private String description;
	private String expectedRevenue;
	private String forecastCategoryName;   //picklist
	private String lastModifiedBy;  
	private Date lastModifiedDate;   
	private String leadSource;
	@Column(length=255)
	private String nextStep;
	private String type;
	private String owner;
	private Integer iqScore;
	private String pricebook2;
	private boolean isPrivate;    //checkbox-- boolean
	private String probability;
	private String primarycampaignsource;
	private String ordernumber;
	private String currentGenerators;
	private String trackingNumber;
	private String mainCompetitor;
	private Integer totalOpportunityQuantity;
	private String opportunitytype;
	private String stage;
	private String status;
	
	private Integer accountid;  //parent
	


}