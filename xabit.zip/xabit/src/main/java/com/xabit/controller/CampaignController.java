package com.xabit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xabit.model.Campaign;
import com.xabit.service.CampaignService;

import lombok.AllArgsConstructor;

@RequestMapping("campaign")
@RestController
@AllArgsConstructor
@CrossOrigin("*")
public class CampaignController {
	@Autowired
	private CampaignService campaignService;
	
	@GetMapping
	public List<Campaign> getAllCampaign(){
		return campaignService.getAllCampaign();
	}

	@GetMapping("/{id}")
	public Campaign getCampaignById(@PathVariable(value = "id") Integer id) {
		return campaignService.getCampaignById(id);
	}
	@PostMapping
	public Campaign createCampaign(@RequestBody Campaign campaign) {
		return campaignService.createCampaign(campaign);
	}
	
	@PutMapping
	public Campaign updateCampaign(@RequestBody Campaign campaign) {
		return campaignService.updateCampaign(campaign);
	}
	@DeleteMapping("/{id}")
	void deleteCampaign(@PathVariable(value = "id") Integer id) {
		campaignService.deleteCampaign(id);
	}
}
