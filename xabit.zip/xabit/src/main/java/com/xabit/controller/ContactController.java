package com.xabit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xabit.model.Contact;
import com.xabit.service.ContactService;

import lombok.AllArgsConstructor;

@RequestMapping("contact")
@RestController
@AllArgsConstructor
@CrossOrigin("*")
public class ContactController {
	@Autowired
	private ContactService contactService;

	@GetMapping
	public List<Contact> getAllContact() {
		return contactService.getAllContact();
	}
	
	@GetMapping("/{id}")
	public Contact getContactById(@PathVariable(value = "id") Integer id) {
		return contactService.getContactById(id);
	}

	@PostMapping
	public Contact createContact(@RequestBody Contact contact) {
		return contactService.createContact(contact);
	}

	@PutMapping
	public Contact updateContact(@RequestBody Contact contact) {
		return contactService.updateContact(contact);
	}

	@DeleteMapping("/{id}")
	void deleteContact(@PathVariable(value = "id") Integer id) {
		contactService.deleteContact(id);
	}
}
