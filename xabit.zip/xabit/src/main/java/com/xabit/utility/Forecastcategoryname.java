package com.xabit.utility;

public enum Forecastcategoryname {
	OMITTED, PIPELINE,BEST_CASE,COMMIT,CLOSED
}
