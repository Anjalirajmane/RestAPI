package com.xabit.utility;

public enum Leadstatus {
	OPEN_NOT_CONTACTED, WORKING_CONTACTED, CLOSED_CONVERTED, CLOSED_NOT_CONVERTED
}
