package com.xabit.utility;

public enum Stage {
//	INPROGRESS, PROPOSAL_SENT, PROPOSAL_ACCEPTED, DISCUSSION, CLOSED_WON, CLOSED_LOST, REJECTED

	PROSPECTING, QUALIFICATION, NEEDS_ANALYSIS, VALUE_PROPOSITION, ID_DECISION_MAKERS, PERCEPTION_ANALYSIS,
	PROPOSAL_QUOTE, NEGOTIATION_REVIEW, CLOSED_WON, CLOSED_LOST

}

//Prospecting
//Qualification
//Needs Analysis
//Value Proposition
//Id. Decision Makers
//Perception Analysis
//Proposal/Price Quote
//Negotiation/Review
//Closed Won
//Closed Lost