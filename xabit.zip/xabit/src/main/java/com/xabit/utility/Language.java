package com.xabit.utility;

public enum Language {
	ENGLISH,CHINESE , JAPANESE
}
