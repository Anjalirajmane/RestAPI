package com.xabitproject.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
//@Table(name = "contact")
@Entity
@Data
public class Contact {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String createdBy;
	private Date createdDate;
	private String  lastModifiedBy;
	private Date  lastModifiedDate;
	private String accountName;
	private Date birthDate;
	private String contactOwner;
	@Column(name="department", length=40)
	private String department;
	@Column(name="description", length=256)
	private String description;
	private String email;
	private String emailOptOut;
	private long homePhone;
	private long mobile;
	@Column(name="firstName", length=40)
	private String firstName;
	@Column(name="lastName", length=40)
	private String lastName;
	private String campaign;
	@Column(name="title", length=40)
	private String title;
	private Integer userId;
	private Integer campaignId ;

}
