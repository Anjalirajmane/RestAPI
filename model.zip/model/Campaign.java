package com.xabitproject.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

//import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
//@Table(name = "campaign_data")
@Entity
@Data
public class Campaign {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String createdBy;
//	@JsonFormat(pattern="dd-MM-yyyy'T'HH:mm:ss.SSS'Z'")
	private Date createdDate;
	private String lastModifiedBy;
	private Date lastModifiedDate;
	private boolean active;
	@Column(name="campaignName", length=30)
	private String campaignName;
	@Column(name="description", length=256)
	private String description;
	private Date startDate;
	private Date endDate;
	private String status;
	private String campaigntype;
	private String parentCampaign;
	private String owner;
	private Integer userId;
	
}
