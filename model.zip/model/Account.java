package com.xabitproject.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String createdBy;
	private Date createdDate;
	private String lastModifiedBy;
	private String accountName;
	private String accountNumber;
	private String accountOwner;
	private String accountSource;
	private String annualRevenue;
	private String billingAddress;
	private String description;
	private int numberOfEmployess;
	private String accountindustry;
	private long phone;
	private String website;
	private String yearStarted;
	private Integer userId;
	
	
//	private String site;
//	private String company;
//	private String jigsaw;
//	private String dunsnumber;
//	private String tier;
//	private String naicscode;
//	private String naicsdesc;
//	private String parent;
//	private String rating;
//	private String shippingaddress;
//	private String sic;
//	private String sicdesc;
//	private String content;
//	private String tradestyle;
//	private String type;
	
	
	
	
}
