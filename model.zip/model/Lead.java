package com.xabitproject.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
//@Table(name = "lead")
@Entity
@Data
public class Lead {
	@Id()
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String createdBy;
	private Date createdDate;
	private String lastModifiedBy;
	private Date lastModifiedDate;
	@Column(name="firstName", length=40)
	private String firstName;
	@Column(name="lastName", length=40)
	private String lastName;
	private String campaign;
	@Column(name="company", length=40)
	private String company;
	@Column(name="description", length=256)
	private String description;
	private String email;
	private String leadindustry;
	private String leadOwner;
	private String leadSource;
	private String leadStatus;
	private long mobile;
	private long phone;
	@Column(name="title", length=40)
	private String title;
	private String website;
	@Column(name="address", length=20)
	private String address;
	@Column(name="street", length=20)
	private String street;
	@Column(name="city", length=20)
	private String city;
	@Column(name="state", length=20)
	private String state;
	@Column(name="country", length=20)
	private String country;
	private Integer campaignId;
	private Integer userId;
}
