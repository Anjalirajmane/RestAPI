package com.xabitproject.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
@Table(name = "user")
@Entity
@Data
public class User {		

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;	
	private String createdBy;
	private Date createdDate;
	private String lastModifiedBy;
	private Date lastModifiedDate;
	@Column(name="alias", length=10)
	private String alias;
	@Column(name="companyName", length=40)
	private String companyName;
	private String email;
	private String userName;
	private String language;
//	private String locale;
	private long mobile;
	@Column(name="firstName", length=20)
	private String firstName;
	@Column(name="lastName", length=20)
	private String lastName;
	@Column(name="title", length=20)
	private String title;
} 

