package com.xabit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xabit.model.Account;
import com.xabit.repository.AccountRepository;

@Service
public class AccountService {
	@Autowired
	private AccountRepository accountRepository;

	public List<Account> getAllAccount() {
		return accountRepository.findAll();
	}

	public Account getAccountById(Integer id) {
		return accountRepository.findById(id).orElse(null);
	}

	public Account createAccount(Account account) {
		return accountRepository.save(account);
	}
	
	public List<Account> findByRating(String rating) {
		return accountRepository.findByRatingIgnoreCase(rating);
	}
	public List<Account> findByOwnership(String ownership) {
		return accountRepository.findByOwnershipIgnoreCase(ownership);
	}
	
	public List<Account> findByAccountType(String accountType) {
		return accountRepository.findByAccountTypeIgnoreCase(accountType);
	}
	public List<Account> findByIndustry(String industry) {
		return accountRepository.findByIndustryIgnoreCase(industry);
	}
	public List<Account> findBySla(String sla) {
		return accountRepository.findBySlaIgnoreCase(sla);
	}
	public List<Account> findByUpsellOpportunity(String upsellOpportunity) {
		return accountRepository.findByUpsellOpportunityIgnoreCase(upsellOpportunity);
	}
	public List<Account> findByCustomerPriority(String customerPriority) {
		return accountRepository.findByCustomerPriorityIgnoreCase(customerPriority);
	}
	
//	public List<Account> findByActive(String active) {
//		return accountRepository.findByActiveIgnoreCase(active);
//	}
	
	public Account updateAccount(Account account) {
		Account account1 = accountRepository.findById(account.getAccountid()).orElse(null);
		account1.setAccountOwner(account.getAccountOwner());
		account1.setAccountName(account.getAccountName());
		account1.setAccountSource(account.getAccountSource());
		account1.setAccountNumber(account.getAccountNumber());
		account1.setCreatedBy(account.getCreatedBy());
		account1.setCreatedDate(account.getCreatedDate());
		account1.setLastModifiedBy(account.getLastModifiedBy());
		account1.setLastModifiedDate(account.getLastModifiedDate());
		account1.setAccountSite(account.getAccountSite());
		account1.setAccountType(account.getAccountType());
		account1.setIndustry(account.getIndustry());
		account1.setRating(account.getRating());
		account1.setPhone(account.getPhone());
		account1.setFax(account.getFax());
		account1.setWebsite(account.getWebsite());
		account1.setTickerSymbol(account.getTickerSymbol());
		account1.setOwnership(account.getOwnership());
		account1.setEmployees(account.getEmployees());
		account1.setAnnualRevenue(account.getAnnualRevenue());
		account1.setSicCode(account.getSicCode());
		account1.setBillingAddress(account.getBillingAddress());
		account1.setBillingStreet(account.getBillingStreet());
		account1.setBillingCity(account.getBillingCity());
		account1.setBillingZipCode(account.getBillingZipCode());
		account1.setBillingState(account.getBillingState());
		account1.setBillingCountry(account.getBillingCountry());
		
		account1.setShippingAddress(account.getShippingAddress());
		account1.setShippingStreet(account.getShippingStreet());
		account1.setShippingCity(account.getShippingCity());
		account1.setShippingZipCode(account.getShippingZipCode());
		account1.setShippingState(account.getShippingState());
		account1.setShippingCountry(account.getShippingCountry());
		
		account1.setCustomerPriority(account.getCustomerPriority());
		account1.setSlaExpirationDate(account.getSlaExpirationDate());
		account1.setNumberOfLocation(account.getNumberOfLocation());
		account1.setSla(account.getSla());
		account1.setSlaSerialNumber(account.getSlaSerialNumber());
		account1.setUpsellOpportunity(account.getUpsellOpportunity());
		account1.setActive(account.isActive());
		account1.setDescription(account.getDescription());
		account1.setNumberOfEmployees(account.getNumberOfEmployees());
		account1.setYearStarted(account.getYearStarted());
		return accountRepository.save(account1);
	}

	public void deleteAccount(Integer id) {
		accountRepository.deleteById(id);
	}
}


