package com.xabit.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.xabit.model.Campaign;

@Repository
public interface CampaignRepository extends JpaRepository<Campaign, Integer>{
	
	List<Campaign> findByTypeIgnoreCase(String type);
	
	List<Campaign> findByStatusIgnoreCase(String status);

}
