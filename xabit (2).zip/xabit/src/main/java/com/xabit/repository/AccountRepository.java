package com.xabit.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.xabit.model.Account;

@Repository
public interface AccountRepository extends JpaRepository<Account, Integer> {

	List<Account> findByRatingIgnoreCase(String rating);

	List<Account> findByOwnershipIgnoreCase(String ownership);

	List<Account> findByAccountTypeIgnoreCase(String accountType);

	List<Account> findByIndustryIgnoreCase(String industry);

	List<Account> findBySlaIgnoreCase(String sla);

	List<Account> findByUpsellOpportunityIgnoreCase(String upsellOpportunity);

	List<Account> findByCustomerPriorityIgnoreCase(String customerPriority);

//	List<Account> findByActiveIgnoreCase(String active);


}
