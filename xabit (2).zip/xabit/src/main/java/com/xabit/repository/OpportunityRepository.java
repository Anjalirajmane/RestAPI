package com.xabit.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.xabit.model.Opportunity;

@Repository
public interface OpportunityRepository extends JpaRepository<Opportunity, Integer> {
	List<Opportunity> findByOpportunityid(String opportunityid);

	List<Opportunity> findByStageIgnoreCase(String stage);

	List<Opportunity> findByOpportunitytypeIgnoreCase(String opportunitytype);

	List<Opportunity> findByleadSourceIgnoreCase(String leadSource);

	List<Opportunity> findByStatusIgnoreCase(String status);

	List<Opportunity> findByAmountAndExpectedRevenueGreaterThan(String amount, String expectedRevenue);

	List<Opportunity> findByAmountAndExpectedRevenueLessThan(String amount, String expectedRevenue);
	
	List<Opportunity> findByAmountAndExpectedRevenueNot(String amount, String expectedRevenue);
	
	List<Opportunity> findByAmountAndExpectedRevenue(String amount, String expectedRevenue);

}
