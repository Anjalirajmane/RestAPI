package com.xabit.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.xabit.model.Lead;

@Repository
public interface LeadRepository extends JpaRepository<Lead, Integer> {
	List<Lead> findByLeadSourceIgnoreCase(String leadSource);

	List<Lead> findByLeadStatusIgnoreCase(String leadStatus);

	List<Lead> findByRatingIgnoreCase(String rating);

	List<Lead> findByIndustryIgnoreCase(String industry);

	List<Lead> findByProductInterestIgnoreCase(String productInterest);

}
