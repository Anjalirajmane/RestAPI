package com.xabit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.xabit.model.Opportunity;
import com.xabit.service.OpportunityService;

import lombok.AllArgsConstructor;

@RequestMapping("opportunity")
@RestController
@AllArgsConstructor
@CrossOrigin("*")
public class OpportunityController {
	@Autowired
	private OpportunityService opportunityService;

	@GetMapping
	public List<Opportunity> getAllOpportunity() {
		return opportunityService.getAllOpportunity();
	}

	@GetMapping("/{id}")
	public Opportunity getOpportunityById(@PathVariable(value = "id") Integer id) {
		return opportunityService.getOpportunityById(id);
	}

	@GetMapping("/by-opportunitytype/{opportunitytype}")
	public List<Opportunity> getOpportunityByOpportunitytype(@PathVariable String opportunitytype) {
		return opportunityService.findByOpportunitytype(opportunitytype);
	}

	@GetMapping("/by-leadSource/{leadSource}")
	public List<Opportunity> getOpportunityByleadSourceIgnoreCase(@PathVariable String leadSource) {
		return opportunityService.findByleadSource(leadSource);
	}

	@GetMapping("/by-stage/{stage}")
	public List<Opportunity> getOpportunityByStageIgnoreCase(@PathVariable String stage) {
		return opportunityService.findByStage(stage);
	}

	@GetMapping("/by-status/{status}")
	public List<Opportunity> getOpportunityByStatusIgnoreCase(@PathVariable String status) {
		return opportunityService.findByStatus(status);
	}

	@GetMapping("/greaterthan")
    public List<Opportunity> getOpportunitiesByAmountAndExpectedRevenueGreaterThan(
            @RequestParam String amount,
            @RequestParam String expectedRevenue) {
        return opportunityService.findOpportunitiesByAmountAndExpectedRevenueGreaterThan(amount, expectedRevenue);
    }

	@GetMapping("/lessthan")
	public List<Opportunity> getOpportunitiesByAmountAndExpectedRevenueLessThan(@RequestParam String amount,
			@RequestParam String expectedRevenue) {
		return opportunityService.findOpportunitiesByAmountAndExpectedRevenueLessThan(amount, expectedRevenue);
	}
	
	@GetMapping("/notequalto")
	public List<Opportunity> getOpportunitiesByAmountAndExpectedRevenueNot(@RequestParam String amount,
			@RequestParam String expectedRevenue) {
		return opportunityService.findOpportunitiesByAmountAndExpectedRevenueNot(amount, expectedRevenue);
	}
	@GetMapping("/equal")
	public List<Opportunity> getOpportunitiesByAmountAndExpectedRevenue(@RequestParam String amount,
			@RequestParam String expectedRevenue) {
		return opportunityService.findOpportunitiesByAmountAndExpectedRevenue(amount, expectedRevenue);
	}
	
	@PostMapping
	public Opportunity createOpportunity(@RequestBody Opportunity opportunity) {
		return opportunityService.createOpportunity(opportunity);
	}

	@PutMapping
	public Opportunity updateOpportunity(@RequestBody Opportunity opportunity) {
		return opportunityService.updateOpportunity(opportunity);
	}

	@DeleteMapping("/{id}")
	void deleteOpportunity(@PathVariable(value = "id") Integer id) {
		opportunityService.deleteOpportunity(id);
	}

}
