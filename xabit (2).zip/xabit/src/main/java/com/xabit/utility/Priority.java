package com.xabit.utility;

public enum Priority {
	HIGH, NORMAL, LOW
}
