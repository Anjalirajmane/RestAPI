package com.xabit.utility;

public enum UpsellOpportunity {
	MAYBE, NO, YES
}
