package com.xabit.utility;

public enum CustomerPriority {
	HIGH, LOW, MEDIUM
}
