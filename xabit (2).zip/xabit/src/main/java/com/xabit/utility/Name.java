package com.xabit.utility;

public enum Name {
	LEAD, CONTACT
}
