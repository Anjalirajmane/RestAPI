package com.xabit.utility;

public enum Ownership {
	PUBLIC, PRIVATE, SUBSIDIARY, OTHER
}
