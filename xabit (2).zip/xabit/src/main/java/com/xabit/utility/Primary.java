package com.xabit.utility;

public enum Primary {
	NO, YES
}
