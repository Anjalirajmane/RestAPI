package com.xabit.utility;

public enum Level {
	PRIMARY, SECONDARY, TERTIARY
}
