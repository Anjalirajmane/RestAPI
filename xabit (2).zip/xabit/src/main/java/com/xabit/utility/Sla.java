package com.xabit.utility;

public enum Sla {
	GOLD, SILVER, PLATINUM, BRONZE
}
