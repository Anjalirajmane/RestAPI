package com.xabit.utility;

public enum Rating {
	HOT, WARM , COLD
}
