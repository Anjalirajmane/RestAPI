package com.xabitproject.utility;

public enum Accountsource {
	WEB, PHONE_INQUIRY, PARTNER_REFERRAL, PURCHASED_LIST, OTHER
}
