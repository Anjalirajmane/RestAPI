package com.xabitproject.utility;

public enum Status {
	PLANNED , IN_PROGRESS , COMPLETED , ABORTED
}
