package com.xabitprojectdemo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.xabitprojectdemo.model.Opportunity;
@Repository
public interface OpportunityRepository extends JpaRepository<Opportunity, String>{
//	List<Opportunity> findByOpportunityIdOrderByCreatedDateAsc(String opportunityId);
	
//	List<Opportunity> findByOpportunityidAndStage(String opportunityid, String stage);
	List<Opportunity> findByStageIgnoreCase(String stage);

}
