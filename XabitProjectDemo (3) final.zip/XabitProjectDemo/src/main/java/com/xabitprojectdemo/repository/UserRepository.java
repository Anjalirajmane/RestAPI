package com.xabitprojectdemo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.xabitprojectdemo.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, String>{

//	List<User> findByLanguageIgnoreCase(String language);
	List<User> findByLanguageIgnoreCase(String language);

//	User findByAlias(String alias);

//	  @Query("SELECT u FROM User u WHERE u.alias = :alias AND u.id <> :userId")
	User findByAliasAndUseridNot(@Param("alias") String alias, @Param("userid") String userid);

//	List<User> findAllByUserId(String Id);
	Optional<User> findByAlias(String alias);

}
