package com.xabitprojectdemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xabitprojectdemo.model.Campaign;
import com.xabitprojectdemo.repository.CampaignRepository;

@Service
public class CampaignService {

	@Autowired
	private CampaignRepository campaignRepository;

	public List<Campaign> getAllCampaign() {
		return campaignRepository.findAll();
	}

	public Campaign getCampaignById(String id) {
		return campaignRepository.findById(id).orElse(null);
	}

	public Campaign createCampaign(Campaign campaign) {
		campaign.setCampaignid(generateID());
		return campaignRepository.save(campaign);
	}

	private String generateID() {
		int len = 15;
		String startString = "CA-";
		int max = 1;

		int startLen = startString.length();
		String maxNum = String.valueOf(max + 1);
		int numLen = maxNum.length();

		int totalZeros = len - startLen - numLen;
		StringBuilder zeroString = new StringBuilder();

		for (int cnt = 1; cnt <= totalZeros; cnt++) {
			zeroString.append("0");
		}

		return startString + zeroString.toString() + maxNum;

	}

	public Campaign updateCampaign(Campaign campaign) {
		Campaign campaign1 = campaignRepository.findById(campaign.getCampaignid()).orElse(null);
		campaign1.setCampaignid(campaign.getCampaignid());
		campaign1.setCreatedBy(campaign.getCreatedBy());
		campaign1.setCreatedDate(campaign.getCreatedDate());
		campaign1.setLastModifiedBy(campaign.getLastModifiedBy());
		campaign1.setLastModifiedDate(campaign.getLastModifiedDate());
		campaign1.setActive(campaign.isActive());
		campaign1.setCampaignName(campaign.getCampaignName());
		campaign1.setDescription(campaign.getDescription());
		campaign1.setStartDate(campaign.getStartDate());
		campaign1.setEndDate(campaign.getEndDate());
		campaign1.setStatus(campaign.getStatus());
		campaign1.setCampaigntype(campaign.getCampaigntype());
		campaign.setParentCampaign(campaign.getParentCampaign());
		campaign1.setOwner(campaign.getOwner());
		campaign1.setUser(campaign.getUser());
		return campaignRepository.save(campaign1);
	}

	public void deleteCampaign(String id) {
		campaignRepository.deleteById(id);
	}
}
