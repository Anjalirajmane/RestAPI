package com.xabitprojectdemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xabitprojectdemo.model.Lead;
import com.xabitprojectdemo.model.Task;
import com.xabitprojectdemo.repository.TaskRepository;

@Service
public class TaskService {
	@Autowired
	private TaskRepository taskRepository;

	// get all list
	public List<Task> getAllTask() {
		return taskRepository.findAll();
	}

	public Task getTaskById(String id) {
		return taskRepository.findById(id).orElse(null);
	}

	public Task createTask(Task task) {
		task.setTaskid(generateID());
		return taskRepository.save(task);
	}

	private String generateID() {
		int len = 15;
		String startString = "T-";
		int max = 2;

		int startLen = startString.length();
		String maxNum = String.valueOf(max + 1);
		int numLen = maxNum.length();

		int totalZeros = len - startLen - numLen;
		StringBuilder zeroString = new StringBuilder();

		for (int cnt = 1; cnt <= totalZeros; cnt++) {
			zeroString.append("0");
		}

		return startString + zeroString.toString() + maxNum;

	}
	public Task updateTask(Task task) {
		Task task1 = taskRepository.findById(task.getTaskid()).orElse(null);
		task1.setAssignedTo(task.getAssignedTo());
		task1.setSubject(task.getSubject());
		task1.setDueDate(task.getDueDate());
		task1.setPriority(task.getPriority());
		task1.setName(task.getName());
		task1.setRelatedTo(task.getRelatedTo());
		task1.setComments(task.getComments());
		task1.setReminder(task.getReminder());
		task1.setTaskType(task.getTaskType());
		task1.setCampaign(task.getCampaign());
		task1.setAccount(task.getAccount());
		task1.setOpportunity(task.getOpportunity());
		task1.setLead(task.getLead());
		task1.setContact(task.getContact());
		task1.setIncomingEmailCount(task.getIncomingEmailCount());
		task1.setOutgoingEmailCount(task.getOutgoingEmailCount());
		task1.setIncomingcallCount(task.getIncomingcallCount());
		task1.setOutgoingcallCount(task.getOutgoingcallCount());
		return taskRepository.save(task1);
	}
	
	public void deleteTask(String id) {
		taskRepository.deleteById(id);
	}
}
