package com.xabitprojectdemo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xabitprojectdemo.model.Account;
import com.xabitprojectdemo.repository.AccountRepository;

@Service
public class AccountService {
	@Autowired
	private AccountRepository accountRepository;

	public List<Account> getAllAccount() {
		return accountRepository.findAll();
	}

	public Account getAccountById(String id) {
		return accountRepository.findById(id).orElse(null);
	}

	public Account createAccount(Account account) {
		account.setAccountid(generateID());
		return accountRepository.save(account);
	}

	private String generateID() {
		int len = 15;
		String startString = "A-";
		int max = 1;

		int startLen = startString.length();
		String maxNum = String.valueOf(max + 1);
		int numLen = maxNum.length();

		int totalZeros = len - startLen - numLen;
		StringBuilder zeroString = new StringBuilder();

		for (int cnt = 1; cnt <= totalZeros; cnt++) {
			zeroString.append("0");
		}

		return startString + zeroString.toString() + maxNum;

	}
	public Account updateAccount(Account account) {
		Account account1 = accountRepository.findById(account.getAccountid()).orElse(null);
		account1.setAccountid(account.getAccountid());
		account1.setCreatedBy(account.getCreatedBy());
		account1.setCreatedDate(account.getCreatedDate());
		account1.setLastModifiedBy(account.getLastModifiedBy());
		account1.setLastModifiedDate(account.getLastModifiedDate());
		account1.setAccountName(account.getAccountName());
		account1.setAccountNumber(account.getAccountNumber());
		account1.setAccountOwner(account.getAccountOwner());
		account1.setAccountSource(account.getAccountSource());
		account1.setAnnualRevenue(account.getAnnualRevenue());
		account1.setBillingAddress(account.getBillingAddress());
		account1.setDescription(account.getDescription());
		account1.setNumberOfEmployees(account.getNumberOfEmployees());
		account1.setAccountindustry(account.getAccountindustry());
		account1.setPhone(account.getPhone());
		account1.setWebsite(account.getWebsite());
		account1.setYearStarted(account.getYearStarted());
		account1.setUser(account.getUser());
		return accountRepository.save(account1);
	}

	public void deleteAccount(String id) {
		accountRepository.deleteById(id);
	}
}
