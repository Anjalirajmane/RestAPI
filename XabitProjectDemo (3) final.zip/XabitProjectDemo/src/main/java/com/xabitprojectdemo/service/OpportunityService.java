package com.xabitprojectdemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xabitprojectdemo.model.Opportunity;
import com.xabitprojectdemo.repository.OpportunityRepository;

@Service
public class OpportunityService {
	@Autowired
	private OpportunityRepository opportunityRepository;

	public List<Opportunity> getAllOpportunity() {
		return opportunityRepository.findAll();
	}

//	public List<Opportunity> findByOpportunityidAndStage(String opportunityid, String stage) {
//        return opportunityRepository.findByOpportunityidAndStage(opportunityid, stage);
//	} 
        
	public Opportunity getOpportunityById(String id) {
		return opportunityRepository.findById(id).orElse(null);
	}
	public List<Opportunity> findByStageIgnoreCase(String stage) {
        return opportunityRepository.findByStageIgnoreCase(stage);
    }

	public Opportunity createOpportunity(Opportunity opportunity) {
		opportunity.setOpportunityid(generateID());
		return opportunityRepository.save(opportunity);
	}

	private String generateID() {
		int len = 15;
		String startString = "O-";
		int max = 2;

		int startLen = startString.length();
		String maxNum = String.valueOf(max + 1);
		int numLen = maxNum.length();

		int totalZeros = len - startLen - numLen;
		StringBuilder zeroString = new StringBuilder();

		for (int cnt = 1; cnt <= totalZeros; cnt++) {
			zeroString.append("0");
		}

		return startString + zeroString.toString() + maxNum;

	}
	public Opportunity updateOpportunity(Opportunity opportunity) {
		Opportunity opportunity1 = opportunityRepository.findById(opportunity.getOpportunityid()).orElse(null);
		opportunity1.setOpportunityid(opportunity.getOpportunityid());
		opportunity1.setAmount(opportunity.getAmount());
		opportunity1.setCloseDate(opportunity.getCloseDate());
		opportunity1.setContact(opportunity.getContact());
//		opportunity1.setContract(opportunity.getContract());
		opportunity1.setCreatedBy(opportunity.getCreatedBy());
		opportunity1.setDescription(opportunity.getDescription());
		opportunity1.setExpectedRevenue(opportunity.getExpectedRevenue());
		opportunity1.setForecastCategoryName(opportunity.getForecastCategoryName());
		opportunity1.setLastModifiedBy(opportunity.getLastModifiedBy());
		opportunity1.setLastModifiedDate(opportunity.getLastModifiedDate());
		opportunity1.setLeadSource(opportunity.getLeadSource());
		opportunity1.setNextStep(opportunity.getNextStep());
		opportunity1.setName(opportunity.getName());
		opportunity1.setOwner(opportunity1.getOwner());
		opportunity1.setIqScore(opportunity.getIqScore());
		opportunity1.setPricebook2(opportunity.getPricebook2());
		opportunity1.setPrivate(opportunity.isPrivate());
		opportunity1.setProbability(opportunity.getProbability());
		opportunity1.setTotalOpportunityQuantity(opportunity.getTotalOpportunityQuantity());
		opportunity1.setStageName(opportunity.getStageName());
		opportunity1.setOpportunitytype(opportunity.getOpportunitytype());
		opportunity1.setAccount(opportunity.getAccount());
		opportunity1.setUser(opportunity.getUser());
		opportunity1.setCampaign(opportunity.getCampaign());
		opportunity1.setStage(opportunity.getStage());
		opportunity1.setStatus(opportunity.getStatus());
//		opportunity1.setUserId(opportunity.getUserid());
//		opportunity1.setCampaignId(opportunity.getCampaignid());

		return opportunityRepository.save(opportunity1);
	}

	public void deleteOpportunity(String id) {
		opportunityRepository.deleteById(id);
	}

}
