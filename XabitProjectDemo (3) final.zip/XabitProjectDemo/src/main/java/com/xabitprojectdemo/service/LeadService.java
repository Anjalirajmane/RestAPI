package com.xabitprojectdemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xabitprojectdemo.model.Lead;
import com.xabitprojectdemo.repository.LeadRepository;

@Service
public class LeadService {

	@Autowired
	private LeadRepository leadRepository;

	public List<Lead> getAllLead() {
		return leadRepository.findAll();
	}

	public Lead getLeadById(String id) {
		return leadRepository.findById(id).orElse(null);
	}

	public Lead createLead(Lead lead) {
		lead.setLeadid(generateID());
		return leadRepository.save(lead);
	}

	private String generateID() {
		int len = 15;
		String startString = "L-";
		int max = 1;

		int startLen = startString.length();
		String maxNum = String.valueOf(max + 1);
		int numLen = maxNum.length();

		int totalZeros = len - startLen - numLen;
		StringBuilder zeroString = new StringBuilder();

		for (int cnt = 1; cnt <= totalZeros; cnt++) {
			zeroString.append("0");
		}

		return startString + zeroString.toString() + maxNum;

	}
	
	public Lead updateLead(Lead lead) {
		Lead lead1 = leadRepository.findById(lead.getLeadid()).orElse(null);
		lead1.setLeadid(lead.getLeadid());
		lead1.setCreatedBy(lead.getCreatedBy());
		lead1.setCreatedDate(lead.getCreatedDate());
		lead1.setLastModifiedBy(lead.getLastModifiedBy());
		lead1.setLastModifiedDate(lead.getLastModifiedDate());
		lead1.setFirstName(lead.getFirstName());
		lead1.setLastName(lead.getLastName());
		lead1.setCompany(lead.getCompany());
		lead1.setDescription(lead.getDescription());
		lead1.setEmail(lead.getEmail());
		lead1.setLeadindustry(lead.getLeadindustry());
		lead1.setLeadOwner(lead.getLeadOwner());
		lead1.setLeadSource(lead.getLeadSource());
		lead1.setLeadStatus(lead.getLeadStatus());
		lead1.setMobile(lead.getMobile());
		lead1.setPhone(lead.getPhone());
		lead1.setTitle(lead.getTitle());
		lead1.setWebsite(lead.getWebsite());
		lead1.setAddress(lead.getAddress());
		lead1.setStreet(lead.getStreet());
		lead1.setCity(lead.getCity());
		lead1.setState(lead.getState());
		lead1.setCountry(lead.getCountry());
		lead1.setUser(lead.getUser());
		lead1.setCampaign(lead.getCampaign());
//		lead1.setCampaignId(lead.getCampaignId());
//		lead1.setUserId(lead.getUserId());

		return leadRepository.save(lead1);
	}

	public void deleteLead(String id) {
		leadRepository.deleteById(id);
	}
}
