package com.xabitprojectdemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xabitprojectdemo.model.Contact;
import com.xabitprojectdemo.repository.ContactRepository;

@Service
public class ContactService {
	@Autowired
	private ContactRepository contactRepository;

	public List<Contact> getAllContact() {
		return contactRepository.findAll();
	}

	public Contact getContactById(String id) {
		return contactRepository.findById(id).orElse(null);
	}

	public Contact createContact(Contact contact) {
		contact.setContactid(generateID());
		return contactRepository.save(contact);
	}

	private String generateID() {
		int len = 15;
		String startString = "CO-";
		int max = 1;

		int startLen = startString.length();
		String maxNum = String.valueOf(max + 1);
		int numLen = maxNum.length();

		int totalZeros = len - startLen - numLen;
		StringBuilder zeroString = new StringBuilder();

		for (int cnt = 1; cnt <= totalZeros; cnt++) {
			zeroString.append("0");
		}

		return startString + zeroString.toString() + maxNum;

	}

	public Contact updateContact(Contact contact) {
		Contact contact1 = contactRepository.findById(contact.getContactid()).orElse(null);
		contact1.setContactid(contact.getContactid());
		contact1.setCreatedBy(contact.getCreatedBy());
		contact1.setCreatedDate(contact.getCreatedDate());
		contact1.setLastModifiedBy(contact.getLastModifiedBy());
		contact1.setBirthDate(contact.getBirthDate());
		contact1.setContactOwner(contact.getContactOwner());
		contact1.setDepartment(contact.getDepartment());
		contact1.setDescription(contact.getDescription());
		contact1.setEmail(contact.getEmail());
		contact1.setEmailOptOut(contact.isEmailOptOut());
		contact1.setHomePhone(contact.getHomePhone());
		contact1.setMobile(contact.getMobile());
		contact1.setFirstName(contact.getFirstName());
		contact1.setLastName(contact.getLastName());
		contact1.setTitle(contact.getTitle());
		contact1.setUser(contact.getUser());
		contact1.setCampaign(contact.getCampaign());
		contact1.setAccount(contact.getAccount());
//		contact1.setUserId(contact.getUserId());
//		contact1.setCampaignId(contact.getCampaignId());
		return contactRepository.save(contact1);
	}

	public void deleteContact(String id) {
		contactRepository.deleteById(id);
	}
}
