package com.xabitprojectdemo.utility;

public enum Language {
	ENGLISH,CHINESE , JAPANESE
}
