package com.xabitprojectdemo.utility;

public enum RelatedTo {
	
	OPPORTUNITY,LEAD, CAMPAIGN, ACCOUNT ,TASK
	
	
}
