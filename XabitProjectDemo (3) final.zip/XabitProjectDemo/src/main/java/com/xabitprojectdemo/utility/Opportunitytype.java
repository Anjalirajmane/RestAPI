package com.xabitprojectdemo.utility;

public enum Opportunitytype {
	EXISTING_CUSTOMER_UPGRADE, EXISTING_CUSTOMER_REPLACEMENT,EXISTING_CUSTOMER_DOWNGRADE, NEW_CUSTOMER
}
