package com.xabitprojectdemo.utility;

public enum Status {

	NOT_STARTED, ON_HOLD, IN_PROGRESS, COMPLETED,YET_TO_BEGIN

}
