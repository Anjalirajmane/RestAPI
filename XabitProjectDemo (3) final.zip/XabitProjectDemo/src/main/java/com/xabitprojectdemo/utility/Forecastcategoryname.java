package com.xabitprojectdemo.utility;

public enum Forecastcategoryname {
	OMITTED, PIPELINE,BEST_CASE,COMMIT,CLOSED
}
