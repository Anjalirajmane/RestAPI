package com.xabitprojectdemo.utility;

public enum Priority {
	HIGH, NORMAL, LOW
}
