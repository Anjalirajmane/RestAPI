package com.xabitprojectdemo.utility;

public enum Leadsource {
	WEB, PHONE_INQUIRY, PARTNER_REFERRAL,PURCHASED_LIST,OTHER
}
