package com.xabitprojectdemo.utility;

public enum Name {
	LEAD, CONTACT
}
