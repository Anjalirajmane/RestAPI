package com.xabitprojectdemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xabitprojectdemo.model.Opportunity;
import com.xabitprojectdemo.service.OpportunityService;
import com.xabitprojectdemo.utility.Stage;

import lombok.AllArgsConstructor;

@RequestMapping("opportunity")
@RestController
@AllArgsConstructor
@CrossOrigin("*")
public class OpportunityController {

	@Autowired
	private OpportunityService opportunityService;

	@GetMapping
	public List<Opportunity> getAllOpportunity() {
		return opportunityService.getAllOpportunity();
	}

	@GetMapping("/{id}")
	public Opportunity getOpportunityById(@PathVariable(value = "id") String id) {
		return opportunityService.getOpportunityById(id);
	}

//	@GetMapping("/{opportunityId}/{stage}")
//    public List<Opportunity> getOpportunityByStage(
//            @PathVariable String opportunityid,
//            @PathVariable String stage) {
//        return opportunityService.findByOpportunityidAndStage(opportunityid, stage);
//    }

//	@GetMapping("/by-stage/{stage}")
//	@GetMapping("/{stage}")
//    public List<Opportunity> getOpportunityByStage(@PathVariable String stage) {
//        return opportunityService.findByStageIgnoreCase(stage);
//    }
	@GetMapping("/by-stage/{stage}")
//	@GetMapping("/{stage}")
    public List<Opportunity> getOpportunityByStage(@PathVariable(value = "stage") Stage stage) {
        return opportunityService.findByStageIgnoreCase(stage.toString());
    }
	
	@PostMapping
	public Opportunity createOpportunity(@RequestBody Opportunity opportunity) {
		return opportunityService.createOpportunity(opportunity);
	}

	@PutMapping
	public Opportunity updateOpportunity(@RequestBody Opportunity opportunity) {
		return opportunityService.updateOpportunity(opportunity);
	}

	@DeleteMapping("/{id}")
	void deleteOpportunity(@PathVariable(value = "id") String id) {
		opportunityService.deleteOpportunity(id);
	}

}
