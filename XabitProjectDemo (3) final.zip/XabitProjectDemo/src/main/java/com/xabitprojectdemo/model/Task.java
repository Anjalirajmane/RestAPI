package com.xabitprojectdemo.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Task {
	@Id
	private String taskid;
	private String assignedTo;
	private String subject;
	private Date dueDate;
	private String priority;
	private String name;     //LEAD, CONTACT
	private String relatedTo;
	private String comments;
	private Date reminder;
	private String taskType;
	private Integer incomingEmailCount;
	private Integer outgoingEmailCount;
	private Integer incomingcallCount;
	private Integer outgoingcallCount;
	
	@ManyToOne
	@JoinColumn(name="campaignid")
    private Campaign campaign;    //parent
	
	@ManyToOne
	@JoinColumn(name="accountid")
    private Account account;    //parent
	
	@ManyToOne
	@JoinColumn(name="opportunityid")
    private Opportunity opportunity;    //parent
	
	@ManyToOne
	@JoinColumn(name="leadid")
    private Lead lead;    //parent
	
	@ManyToOne
	@JoinColumn(name="contactid")
    private Contact contact;    //parent
	
	
	
	
}
