package com.xabitprojectdemo.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Account {
	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
	private String accountid;
	private String createdBy;
	private Date createdDate;
	private String lastModifiedBy;
	private Date lastModifiedDate;
	@Column(length=40)
	private String accountName;
	@Column(length=40)
	private String accountNumber;
	private String accountOwner;
	private String accountSource;
	private String annualRevenue;
	private String billingAddress;
	private String description;
	private Integer numberOfEmployees;
	private String accountindustry;
	private long phone;
	private String website;
	private String yearStarted;
	
	@ManyToOne
    @JoinColumn(name = "userid")
	private User user; //parent
	
	
		
}
