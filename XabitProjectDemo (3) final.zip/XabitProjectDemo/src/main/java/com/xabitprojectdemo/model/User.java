package com.xabitprojectdemo.model;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Table(name = "user")
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {

	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)

	private String userid;
	@Column(unique = true , length=10)
	private String alias;
	@Column(length=20)
	private String firstName;
	@Column(length=20)
	private String lastName;
	private String createdBy;
	private Date createdDate;
	private String lastModifiedBy;
	private Date lastModifiedDate;
	@Column(length=40)
	private String companyName;
	private String email;
	@Column(unique = true)
	private String userName;
	private String language;
	private String locale;
	private long mobile;
	private String title;

}
