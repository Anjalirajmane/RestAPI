package com.xabitprojectdemo.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
//@Table(name = "contact")
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Contact {
	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
	private String contactid;
	private String createdBy;
	private Date createdDate;
	private String lastModifiedBy;
	private Date lastModifiedDate;
//	private Account accountName;
	private Date birthDate;
	private String contactOwner;
	@Column(name="department", length=40)
	private String department;
	@Column(name="description", length=256)
	private String description;
	private String email;
	private boolean emailOptOut;
	private long homePhone;
	private long mobile;
	@Column(name="firstName", length=40)
	private String firstName;
	@Column(name="lastName", length=40)
	private String lastName;
	@Column(length=40)
	private String title;
//	private Campaign campaign;
	
	@ManyToOne
    @JoinColumn(name = "userid")
	private User user; //parent
	
	@ManyToOne
	@JoinColumn(name="campaignid")
    private Campaign campaign;    //parent
	
	@ManyToOne 
	@JoinColumn(name="accountid")
	private Account account; //parent


}