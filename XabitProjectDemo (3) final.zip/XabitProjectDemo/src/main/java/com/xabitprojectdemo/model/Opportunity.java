package com.xabitprojectdemo.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Opportunity {
	@Id
	private String opportunityid;
//	private String account;
	private String amount;
	private Date closeDate;  //date
	private String contact;  //lookup
	private String createdBy;
	private String description;
	private String expectedRevenue;
	private String forecastCategoryName;   //picklist
	private String lastModifiedBy;  
	private Date lastModifiedDate;   
	private String leadSource;
	@Column(length=255)
	private String nextStep;
	@Column(length=120)
	private String name;
	private String owner;
	private Integer iqScore;
	private String pricebook2;
//	private Campaign campaign;
	private boolean isPrivate;    //checkbox-- boolean
	private String probability;
	private Integer totalOpportunityQuantity;
	private String stageName;
	private String opportunitytype;
	private String stage;
	private String status;
	
	@ManyToOne
    @JoinColumn(name = "userid")
	private User user; //parent
	
	@ManyToOne
	@JoinColumn(name="campaignid")
    private Campaign campaign;    //parent
			
	@ManyToOne
	@JoinColumn(name="accountid")
    private Account account;    //parent
	

}

//@GeneratedValue(strategy = GenerationType.AUTO)