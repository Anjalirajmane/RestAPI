package com.xabitprojectdemo.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;

//import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.NoArgsConstructor;
//@Table(name = "campaign_data")
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Campaign {
	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
	private String campaignid;
	private String createdBy;
	private Date createdDate;
	private String lastModifiedBy;
	private Date lastModifiedDate;
	private boolean active;
	@Column (length=30)
	private String campaignName;
	@Column(length=256)
	private String description;
	private Date startDate;
	private Date endDate;
	private String status;
	private String campaigntype;
	private String parentCampaign;
	private String owner;
	
	@ManyToOne
    @JoinColumn(name = "userid")
	private User user; //parent
	
}

