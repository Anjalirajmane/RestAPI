package com.xabitprojectdemo.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
//@Table(name = "lead")
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Lead {
	@Id()
//	@GeneratedValue(strategy = GenerationType.AUTO)
	private String leadid;
	private String createdBy;
	private Date createdDate;
	private String lastModifiedBy;
	private Date lastModifiedDate;
	@Column(name="firstName", length=40)
	private String firstName;
	@Column(name="lastName", length=40)
	private String lastName;
	@Column(name="company", length=40)
	private String company;
	@Column(length=256)
	private String description;
	private String email;
	private String leadindustry;
	private String leadOwner;
	private String leadSource;
	private String leadStatus;
	private long mobile;
	private long phone;
	@Column(length=40)
	private String title;
	private String website;
	@Column(length=20)
	private String address;
	@Column(length=20)
	private String street;
	@Column(length=20)
	private String city;
	@Column(length=20)
	private String state;
	@Column(length=20)
	private String country;

	@ManyToOne
    @JoinColumn(name = "userid")
	private User user; //parent
	
	@ManyToOne
	@JoinColumn(name="campaignid")
    private Campaign campaign;    //parent
	
	
}
