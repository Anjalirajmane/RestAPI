package com.xabitprojectdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XabitProjectDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(XabitProjectDemoApplication.class, args);
	}

}
