package com.xabit.utility;

public enum RelatedTo {
	
	OPPORTUNITY,LEAD, CAMPAIGN, ACCOUNT ,TASK
	
	
}
