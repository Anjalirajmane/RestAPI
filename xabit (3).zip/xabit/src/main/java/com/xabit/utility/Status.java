package com.xabit.utility;

public enum Status {

	NOT_STARTED, ON_HOLD, IN_PROGRESS, COMPLETED,YET_TO_BEGIN

}
