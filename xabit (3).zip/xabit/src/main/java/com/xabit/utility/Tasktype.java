package com.xabit.utility;

public enum Tasktype {

	EMAIL, PHONE ,VOICE_MAIL, SMS, WHATSAPP, CALL
}
