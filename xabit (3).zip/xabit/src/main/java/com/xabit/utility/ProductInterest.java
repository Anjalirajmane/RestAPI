package com.xabit.utility;

public enum ProductInterest {
	GC1000_SERIES, GC5000_SERIES ,GC3000_SERIES
}
