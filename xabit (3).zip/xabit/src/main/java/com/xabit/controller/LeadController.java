package com.xabit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xabit.model.Lead;
import com.xabit.service.LeadService;


import lombok.AllArgsConstructor;

@RequestMapping("lead")
@RestController
@AllArgsConstructor
@CrossOrigin("*")
public class LeadController {
	@Autowired
	private LeadService leadService;

	@GetMapping
	public List<Lead> getAllLead() {
		return leadService.getAllLead();
	}
	@GetMapping("/{id}")
	public Lead getLeadById(@PathVariable(value = "id") Integer id) {
		return leadService.getLeadById(id);
	}

	@PostMapping
	public Lead createLead(@RequestBody Lead lead) {
		return leadService.createLead(lead);
	}
	
	@GetMapping("/by-leadSource/{leadSource}")
	public List<Lead> getLeadByLeadSourceIgnoreCase(@PathVariable String leadSource) {
		return leadService.findByLeadSource(leadSource);
	}
	@GetMapping("/by-leadStatus/{leadStatus}")
	public List<Lead> getLeadByLeadStatusIgnoreCase(@PathVariable String leadStatus) {
		return leadService.findByLeadStatus(leadStatus);
	}
	@GetMapping("/by-rating/{rating}")
	public List<Lead> getLeadByRatingIgnoreCase(@PathVariable String rating) {
		return leadService.findByRating(rating);
	}
	@GetMapping("/by-leadindustry/{leadindustry}")
	public List<Lead> getLeadByIndustryIgnoreCase(@PathVariable String industry) {
		return leadService.findByIndustry(industry);
	}
	@GetMapping("/by-productInterest/{productInterest}")
	public List<Lead> getLeadByProductInterestIgnoreCase(@PathVariable String productInterest) {
		return leadService.findByProductInterest(productInterest);
	}
	    
	
	@PutMapping
	public Lead updateLead(@RequestBody Lead lead) {
		return leadService.updateLead(lead);
	}

	@DeleteMapping("/{id}")
	void deleteLead(@PathVariable(value = "id") Integer id) {
		leadService.deleteLead(id);
	}
}
