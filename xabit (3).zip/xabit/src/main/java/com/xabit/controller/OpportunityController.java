package com.xabit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.xabit.model.Opportunity;
import com.xabit.service.OpportunityService;

import lombok.AllArgsConstructor;

@RequestMapping("opportunity")
@RestController
@AllArgsConstructor
@CrossOrigin("*")
public class OpportunityController {
	@Autowired
	private OpportunityService opportunityService;

	@GetMapping
	public List<Opportunity> getAllOpportunity() {
		return opportunityService.getAllOpportunity();
	}

	@GetMapping("/{id}")
	public Opportunity getOpportunityById(@PathVariable(value = "id") Integer id) {
		return opportunityService.getOpportunityById(id);
	}

	@GetMapping("/by-type/{type}")
	public List<Opportunity> getOpportunityByType(@PathVariable String type) {
		return opportunityService.findByType(type);
	}

	@GetMapping("/by-leadSource/{leadSource}")
	public List<Opportunity> getOpportunityByleadSourceIgnoreCase(@PathVariable String leadSource) {
		return opportunityService.findByleadSource(leadSource);
	}

	@GetMapping("/by-stage/{stage}")
	public List<Opportunity> getOpportunityByStageIgnoreCase(@PathVariable String stage) {
		return opportunityService.findByStage(stage);
	}

	@GetMapping("/by-status/{status}")
	public List<Opportunity> getOpportunityByStatusIgnoreCase(@PathVariable String status) {
		return opportunityService.findByStatus(status);
	}

	@GetMapping("/greaterthan/{amount}")
	public List<Opportunity> getOpportunitiesByAmountGreaterThan(@RequestParam String amount) {
		return opportunityService.findOpportunitiesByAmountGreaterThan(amount);
	}

	@GetMapping("/lessthan/{amount}")
	public List<Opportunity> getOpportunitiesByAmountLessThan(@RequestParam String amount) {
		return opportunityService.findOpportunitiesByAmountLessThan(amount);
	}

	@GetMapping("/notequalto/{amount}")
	public List<Opportunity> getOpportunitiesByAmountNot(@RequestParam String amount) {
		return opportunityService.findOpportunitiesByAmountNot(amount);
	}

	@GetMapping("/equal/{amount}")
	public List<Opportunity> getOpportunitiesByAmount(@RequestParam String amount) {
		return opportunityService.findOpportunitiesByAmount(amount);
	}

	@GetMapping("/greaterthan")
	public List<Opportunity> getOpportunitiesByExpectedRevenueGreaterThan(@RequestParam String expectedRevenue) {
		return opportunityService.findOpportunitiesByExpectedRevenueGreaterThan(expectedRevenue);
	}

	@GetMapping("/lessthan")
	public List<Opportunity> getOpportunitiesByExpectedRevenueLessThan(@RequestParam String expectedRevenue) {
		return opportunityService.findOpportunitiesByExpectedRevenueLessThan(expectedRevenue);
	}

	@GetMapping("/notequalto")
	public List<Opportunity> getOpportunitiesByExpectedRevenueNot(@RequestParam String expectedRevenue) {
		return opportunityService.findOpportunitiesByExpectedRevenueNot(expectedRevenue);
	}

	@GetMapping("/equal")
	public List<Opportunity> getOpportunitiesByExpectedRevenue(@RequestParam String expectedRevenue) {
		return opportunityService.findOpportunitiesByExpectedRevenue(expectedRevenue);
	}

	@PostMapping
	public Opportunity createOpportunity(@RequestBody Opportunity opportunity) {
		return opportunityService.createOpportunity(opportunity);
	}

	@PutMapping
	public Opportunity updateOpportunity(@RequestBody Opportunity opportunity) {
		return opportunityService.updateOpportunity(opportunity);
	}

	@DeleteMapping("/{id}")
	void deleteOpportunity(@PathVariable(value = "id") Integer id) {
		opportunityService.deleteOpportunity(id);
	}

}
