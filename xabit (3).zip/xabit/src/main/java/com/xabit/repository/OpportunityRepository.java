package com.xabit.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.xabit.model.Opportunity;

@Repository
public interface OpportunityRepository extends JpaRepository<Opportunity, Integer> {
	List<Opportunity> findByOpportunityid(String opportunityid);

	List<Opportunity> findByStageIgnoreCase(String stage);

	List<Opportunity> findByTypeIgnoreCase(String type);

	List<Opportunity> findByleadSourceIgnoreCase(String leadSource);

	List<Opportunity> findByStatusIgnoreCase(String status);

	List<Opportunity> findByAmountGreaterThan(String amount);

	List<Opportunity> findByAmountLessThan(String amount);
	// not equal to api
	List<Opportunity> findByAmountNot(String amount);
	//equal api
	List<Opportunity> findByAmount(String amount);
	
	List<Opportunity> findByExpectedRevenueGreaterThan(String expectedRevenue);

	List<Opportunity> findByExpectedRevenueLessThan(String expectedRevenue);
	// not equal to api
	List<Opportunity> findByExpectedRevenueNot(String expectedRevenue);
	//equal api
	List<Opportunity> findByExpectedRevenue(String expectedRevenue);

}
