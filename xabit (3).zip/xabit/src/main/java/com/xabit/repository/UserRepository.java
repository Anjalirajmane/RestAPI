package com.xabit.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.xabit.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
	List<User> findByLanguageIgnoreCase(String language);

//	@Query("SELECT u FROM User u WHERE u.alias = :alias AND u.id <> :userId")
	User findByAliasAndUseridNot(@Param("alias") String alias, @Param("userid") String userid);

	Optional<User> findByAlias(String alias);
}
