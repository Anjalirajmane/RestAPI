package com.xabit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xabit.model.Lead;
import com.xabit.repository.LeadRepository;


@Service
public class LeadService {
	@Autowired
	private LeadRepository leadRepository;

	public List<Lead> getAllLead() {
		return leadRepository.findAll();
	}

	public Lead getLeadById(Integer id) {
		return leadRepository.findById(id).orElse(null);
	}

	public Lead createLead(Lead lead) {
		return leadRepository.save(lead);
	}
	
	public List<Lead> findByLeadSource(String leadSource) {
		return leadRepository.findByLeadSourceIgnoreCase(leadSource);
	}
	public List<Lead> findByLeadStatus(String leadStatus) {
		return leadRepository.findByLeadStatusIgnoreCase(leadStatus);
	}
	
	public List<Lead> findByRating(String rating) {
		return leadRepository.findByRatingIgnoreCase(rating);
	}
	public List<Lead> findByIndustry(String industry) {
		return leadRepository.findByIndustryIgnoreCase(industry);
	}
	public List<Lead> findByProductInterest(String productInterest) {
		return leadRepository.findByProductInterestIgnoreCase(productInterest);
	}
	
	
	public Lead updateLead(Lead lead) {
		Lead lead1 = leadRepository.findById(lead.getLeadid()).orElse(null);
		lead1.setSalutation(lead.getSalutation());
		lead1.setOwner(lead.getOwner());
		lead1.setFirstName(lead.getFirstName());
		lead1.setLastName(lead.getLastName());
		lead1.setCompany(lead.getCompany());
		lead1.setTitle(lead.getTitle());
		lead1.setCreatedBy(lead.getCreatedBy());
		lead1.setCreatedDate(lead.getCreatedDate());
		lead1.setLastModifiedBy(lead.getLastModifiedBy());
		lead1.setLastModifiedDate(lead.getLastModifiedDate());
		lead1.setMobile(lead.getMobile());
		lead1.setPhone(lead.getPhone());
		lead1.setEmail(lead.getEmail());
		lead1.setFax(lead.getFax());
		lead1.setLeadStatus(lead.getLeadStatus());
		lead1.setLeadSource(lead.getLeadSource());
		lead1.setLeadOwner(lead.getLeadOwner());
		lead1.setDescription(lead.getDescription());
		lead1.setIndustry(lead.getIndustry());
		lead1.setWebsite(lead.getWebsite());
		lead1.setAnnualRevenue(lead.getAnnualRevenue());
		lead1.setNoOfEmployees(lead.getNoOfEmployees());
		lead1.setRating(lead.getRating());
		lead1.setAddress(lead.getAddress());
		lead1.setStreet(lead.getStreet());
		lead1.setCity(lead.getCity());
		lead1.setState(lead.getState());
		lead1.setZipCode(lead.getZipCode());
		lead1.setCountry(lead.getCountry());
		lead1.setProductInterest(lead.getProductInterest());
		lead1.setCurrentGenerator(lead.getCurrentGenerator());
		lead1.setSicCode(lead.getSicCode());
		lead1.setPrimary(lead.getPrimary());
		lead1.setNumberOfLocations(lead.getNumberOfLocations());
		lead1.setCampaignid(lead.getCampaignid());
		return leadRepository.save(lead1);
	}

	public void deleteLead(Integer id) {
		leadRepository.deleteById(id);
	}
}


