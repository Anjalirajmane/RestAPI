package com.xabit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xabit.model.Contact;
import com.xabit.repository.ContactRepository;

@Service
public class ContactService {
	@Autowired
	private ContactRepository contactRepository;

	public List<Contact> getAllContact() {
		return contactRepository.findAll();
	}

	public Contact getContactById(Integer id) {
		return contactRepository.findById(id).orElse(null);
	}

	public Contact createContact(Contact contact) {
		
		
		// billing address - TODO
		/*
		 * String billingAddress=contact.getEmail().concat(contact.getFirstName());
		 * contact.setBiilingAddress(billingAddress);
		 */
		
		return contactRepository.save(contact);
	}
	
	
	public List<Contact> findByLeadSource(String leadSource) {
		return contactRepository.findByLeadSourceIgnoreCase(leadSource);
	}
	
	public List<Contact> findByLevel(String level){
		return contactRepository.findByLevelIgnoreCase(level);
	}
	
	public Contact updateContact(Contact contact) {
		Contact contact1 = contactRepository.findById(contact.getContactid()).orElse(null);
		contact1.setOwner(contact.getOwner());
		contact1.setSalutation(contact.getSalutation());
		contact1.setFirstName(contact.getFirstName());
		contact1.setLastName(contact.getLastName());
		contact1.setCreatedBy(contact.getCreatedBy());
		contact1.setCreatedDate(contact.getCreatedDate());
		contact1.setLastModifiedBy(contact.getLastModifiedBy());
		contact1.setLastModifiedDate(contact.getLastModifiedDate());
		contact1.setTitle(contact.getTitle());
		contact1.setAsstPhone(contact.getPhone());
		contact1.setHomePhone(contact.getHomePhone());
		contact1.setMobile(contact.getMobile());
		contact1.setOtherPhone(contact.getOtherPhone());
		contact1.setBirthDate(contact.getBirthDate());
		contact1.setDepartment(contact.getDepartment());
		contact1.setEmail(contact.getEmail());
		contact1.setEmailOptOut(contact.isEmailOptOut());
		contact1.setFax(contact.getFax());
		contact1.setReportsTo(contact.getReportsTo());
		contact1.setLeadSource(contact.getLeadSource());
		contact1.setAssistant(contact.getAssistant());
		contact1.setAsstPhone(contact.getAsstPhone());
		contact1.setMailingAddress(contact.getMailingAddress());
		contact1.setMailingStreet(contact.getMailingStreet());
		contact1.setMailingCity(contact.getMailingCity());
		contact1.setMailingZipCode(contact.getMailingZipCode());
		contact1.setMailingState(contact.getMailingState());
		contact1.setMailingCountry(contact.getMailingCountry());
		contact1.setOtherAddress(contact.getOtherAddress());
		contact1.setOtherStreet(contact.getOtherStreet());
		contact1.setOtherCity(contact.getOtherCity());
		contact1.setOtherZipCode(contact.getOtherZipCode());
		contact1.setOtherState(contact.getOtherState());
		contact1.setOtherCountry(contact.getOtherCountry());
		contact1.setLanguages(contact1.getLanguages());
		contact1.setLevel(contact.getLevel());
		contact1.setDescription(contact.getDescription());
		contact1.setAccountid(contact.getAccountid());
		contact.setCampaignid(contact.getCampaignid());
		
		return contactRepository.save(contact1);
	}

	public void deleteContact(Integer id) {
		contactRepository.deleteById(id);
	}
}


