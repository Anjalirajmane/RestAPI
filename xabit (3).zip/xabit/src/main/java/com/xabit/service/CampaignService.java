package com.xabit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xabit.model.Campaign;
import com.xabit.repository.CampaignRepository;

@Service
public class CampaignService {
	@Autowired
	private CampaignRepository campaignRepository;

	public List<Campaign> getAllCampaign() {
		return campaignRepository.findAll();
	}

	public Campaign getCampaignById(Integer id) {
		return campaignRepository.findById(id).orElse(null);
	}
	
	public Campaign createCampaign(Campaign campaign) {
		return campaignRepository.save(campaign);
	}
	
	public List<Campaign> findByStatus(String status) {
		return campaignRepository.findByStatusIgnoreCase(status);
	}
	
	public List<Campaign> findByType(String type) {
		return campaignRepository.findByTypeIgnoreCase(type);
	}
	

	public Campaign updateCampaign(Campaign campaign) {
		Campaign campaign1 = campaignRepository.findById(campaign.getCampaignid()).orElse(null);
		campaign1.setOwner(campaign.getOwner());
		campaign1.setCreatedBy(campaign.getCreatedBy());
		campaign1.setCreatedDate(campaign.getCreatedDate());
		campaign1.setLastModifiedBy(campaign.getLastModifiedBy());
		campaign1.setLastModifiedDate(campaign.getLastModifiedDate());
		campaign1.setCampaignName(campaign.getCampaignName());
		campaign1.setActive(campaign.isActive());
		campaign1.setType(campaign.getType());
		campaign1.setStatus(campaign.getStatus());
		campaign1.setStartDate(campaign.getStartDate());
		campaign1.setEndDate(campaign.getEndDate());
		campaign1.setParentCampaign(campaign.getParentCampaign());
		campaign1.setExpectedRevenueInCampaign(campaign.getExpectedRevenueInCampaign());
		campaign1.setBudgetedCostInCampaign(campaign.getBudgetedCostInCampaign());
		campaign1.setActualCostInCampaign(campaign.getActualCostInCampaign());
		campaign1.setExpectedResponse(campaign.getExpectedResponse());
		campaign1.setNumSentInCampaign(campaign.getNumSentInCampaign());
		campaign1.setDescription(campaign.getDescription());
		return campaignRepository.save(campaign1);
	}

	public void deleteCampaign(Integer id) {
		campaignRepository.deleteById(id);
	}
}


